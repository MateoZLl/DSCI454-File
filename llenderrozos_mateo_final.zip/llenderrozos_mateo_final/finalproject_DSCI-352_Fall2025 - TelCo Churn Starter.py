"""
Starter File – Telco Customer Churn (Keras + Sklearn + Optional AWS)

This is a starter script for your final project.

Your high-level goals:

1. Load and clean the Telco Customer Churn dataset.
2. Build a preprocessing pipeline that:
   - Handles numeric and categorical variables.
   - Imputes missing values.
   - Scales numeric features and one-hot encodes categorical features.
3. Train several ML models (scikit-learn + Keras):
   - Compare their performance (AUC, accuracy).
   - Interpret which model performs best and why.
4. (Bonus) Build a lightweight artifact suitable for deployment in AWS Lambda:
   - Export only the parameters needed to recreate the preprocessing + a simple model.
   - Upload this artifact to S3 if AWS export is enabled.

IMPORTANT:
- All places marked with "TODO (Student)" or "TODO" are for you to implement.
- As given, this file will raise NotImplementedError in several places.
  Your job is to replace those with working code. Disclaimer: this piece was AI generated.

Files:
- Input CSV: WA_Fn-UseC_-Telco-Customer-Churn.csv
"""

import os
import io
import json

import numpy as np
import pandas as pd
import tensorflow as tf
from tensorflow import keras
from tensorflow.keras import layers

from sklearn.model_selection import train_test_split
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder
from sklearn.impute import SimpleImputer
from sklearn.metrics import roc_auc_score, accuracy_score
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.linear_model import SGDClassifier
from sklearn.preprocessing import StandardScaler

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import seaborn as sns

LOCAL_CSV = "WA_Fn-UseC_-Telco-Customer-Churn.csv"

# not using any aws functionality
# AWS Config (for Bonus)
S3_BUCKET = os.environ.get("MODEL_BUCKET", "769341382710-model")
S3_KEY_LIGHT = os.environ.get("MODEL_KEY", "models/telco_churn_light.json")
AWS_REGION = os.environ.get("AWS_REGION", "us-east-1")

# Flag: make AWS completely optional
#   - False: run everything locally; no S3 upload
#   - True : in addition, build a lightweight artifact and upload to S3 (bonus)
ENABLE_AWS_EXPORT = False


# Data Loading and helpers (given to you)
def load_telco(path: str) -> pd.DataFrame:
    """
    Load the Telco CSV and perform basic cleaning:
      - Convert TotalCharges to numeric (coerce errors to NaN).
      - Convert Churn to 0/1.
      - Drop customerID (not useful as a feature).

    You can inspect and modify this function if you want, but it's provided
    as a starting point.
    """
    df = pd.read_csv(path)
    df["TotalCharges"] = pd.to_numeric(df["TotalCharges"], errors="coerce")
    df["Churn"] = df["Churn"].map({"Yes": 1, "No": 0})
    df = df.drop(columns=["customerID"], errors="ignore")
    return df


def build_preprocessor(df: pd.DataFrame):
    """
    Build a ColumnTransformer that:
      - Applies a numeric pipeline to numeric columns.
      - Applies a categorical pipeline to categorical columns.

    Numeric pipeline:
      - SimpleImputer(strategy="median")
      - StandardScaler()

    Categorical pipeline:
      - SimpleImputer(strategy="most_frequent")
      - OneHotEncoder(handle_unknown="ignore", sparse_output=False)

    Returns:
      preprocessor, X, y, numeric_feature_names, categorical_feature_names
    """
    X = df.drop("Churn", axis=1)
    y = df["Churn"]

    numeric_features = X.select_dtypes(include=["int64", "float64"]).columns.tolist()
    categorical_features = X.select_dtypes(include=["object", "bool"]).columns.tolist()

    numeric_transformer = Pipeline(
        steps=[
            ("imputer", SimpleImputer(strategy="median")),
            ("scaler", StandardScaler()),
        ]
    )
    categorical_transformer = Pipeline(
        steps=[
            ("imputer", SimpleImputer(strategy="most_frequent")),
            ("onehot", OneHotEncoder(handle_unknown="ignore", sparse_output=False)),
        ]
    )

    preprocessor = ColumnTransformer(
        transformers=[
            ("num", numeric_transformer, numeric_features),
            ("cat", categorical_transformer, categorical_features),
        ]
    )
    return preprocessor, X, y, numeric_features, categorical_features


def make_numpy_for_keras(preprocessor, X_train, X_val):
    """
    Fit the preprocessor on X_train, transform train+val, and return dense
    numpy arrays so that Keras can use them.

    Also returns feature_names for inspection (not required for training).
    """
    preprocessor.fit(X_train)
    X_train_proc = preprocessor.transform(X_train)
    X_val_proc = preprocessor.transform(X_val)

    ohe = preprocessor.named_transformers_["cat"].named_steps["onehot"]
    cat_names = ohe.get_feature_names_out()
    num_names = preprocessor.transformers_[0][2]
    feature_names = np.concatenate([num_names, cat_names])

    return X_train_proc.astype("float32"), X_val_proc.astype("float32"), feature_names


class GradientTracker(keras.callbacks.Callback):
    """
    Tracks gradient statistics after each epoch for a Keras model.

    This helps you reason about gradient health
    (e.g. vanishing/exploding gradients).
    """

    def __init__(self, model, sample_x, sample_y):
        super().__init__()
        self.model_for_grads = model
        self.sample_x = tf.convert_to_tensor(sample_x)
        self.sample_y = tf.convert_to_tensor(sample_y, dtype=tf.float32)
        self.history = []

    def on_epoch_end(self, epoch, logs=None):
        with tf.GradientTape() as tape:
            preds = self.model_for_grads(self.sample_x, training=True)  # (batch, 1)
            preds = tf.squeeze(preds, axis=-1)  # -> (batch,)
            loss = keras.losses.binary_crossentropy(self.sample_y, preds)
            loss = tf.reduce_mean(loss)

        grads = tape.gradient(loss, self.model_for_grads.trainable_weights)
        grad_vals = [tf.reshape(g, [-1]) for g in grads if g is not None]
        if grad_vals:
            all_grads = tf.concat(grad_vals, axis=0)
            grad_mean = tf.reduce_mean(tf.abs(all_grads)).numpy().item()
            grad_max = tf.reduce_max(tf.abs(all_grads)).numpy().item()
            grad_std = tf.math.reduce_std(all_grads).numpy().item()
        else:
            grad_mean = grad_max = grad_std = 0.0

        self.history.append(
            {
                "epoch": int(epoch),
                "grad_abs_mean": grad_mean,
                "grad_abs_max": grad_max,
                "grad_std": grad_std,
                "loss": float(loss.numpy()),
                "logs": logs or {},
            }
        )


def build_keras_model(input_dim: int):
    model = keras.Sequential([
        layers.Input(shape=(input_dim,)),
        layers.Dense(128, activation="relu"),
        layers.Dropout(0.3), # dropout reduce overfitting
        layers.Dense(64, activation="relu"),
        layers.Dropout(0.3),
        layers.Dense(32, activation="relu"),
        layers.Dense(1, activation="sigmoid"),
    ])

    model.compile(
        optimizer=keras.optimizers.Adam(learning_rate=1e-3),
        loss="binary_crossentropy",
        metrics=[keras.metrics.AUC(name="auc"), "accuracy"],
    )
    return model


def train_sklearn_models(preprocessor, X, y):
    # create train/test splits
    X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=2026, stratify=y)

    # these are all the models we will be comparing
    candidates = [
        ("logistic_regression", LogisticRegression(max_iter=100)),
        ("random_forest", RandomForestClassifier(n_estimators=50, max_depth=8, random_state=2026)),
        ("gradient_boosting", GradientBoostingClassifier(n_estimators=50, max_depth=4, learning_rate=0.05, random_state=2026)),
        ("sgd_log", SGDClassifier(loss="log_loss", max_iter=100, random_state=2026)),
    ]

    results = []
    sgd_model, sgd_auc = None, None

    # run each of the candidates
    # obtain metrics to compare
    for name, clf in candidates:
        pipeline = Pipeline([("preprocessor", preprocessor), ("classifier", clf)])
        pipeline.fit(X_train, y_train)
        proba = pipeline.predict_proba(X_val)[:, 1]
        auc = roc_auc_score(y_val, proba)
        results.append((name, pipeline, auc))
        if name == "sgd_log":
            sgd_model, sgd_auc = pipeline, auc

    results.sort(key=lambda x: x[2], reverse=True)

    # return all results including splits
    return results, (X_train, X_val, y_train, y_val), sgd_model, sgd_auc


def main():
    # Step 0: Load data
    if not os.path.exists(LOCAL_CSV):
        raise FileNotFoundError(f"CSV not found at {LOCAL_CSV}")

    print("Loading telco data...")
    df = load_telco(LOCAL_CSV)

    # Step 1: Preprocessor
    print("Building preprocessor...")
    preprocessor, X, y, num_feats, cat_feats = build_preprocessor(df)

    # Step 2: Scikit-Learn models
    print("Training sklearn models...")
    sk_results, splits, sgd_model, sgd_auc = train_sklearn_models(preprocessor, X, y)
    (X_train, X_val, y_train, y_val) = splits

    # sk_results should be sorted by AUC (descending)
    best_sklearn_name, best_sklearn_model, best_sklearn_auc = sk_results[0]

    # Step 3: Keras model
    print("Preparing numpy for Keras...")
    X_train_np, X_val_np, feature_names = make_numpy_for_keras(
        preprocessor, X_train, X_val
    )

    print("Building Keras model...")
    keras_model = build_keras_model(input_dim=X_train_np.shape[1])

    # pick a small fixed batch for gradient tracking
    sample_x = X_train_np[:256]
    sample_y = y_train.values[:256]
    grad_tracker = GradientTracker(keras_model, sample_x, sample_y)

    print("Training Keras model...")
    history = keras_model.fit(
        X_train_np,
        y_train.values,
        validation_data=(X_val_np, y_val.values),
        epochs=20,          # you can tune
        batch_size=256,     # you can tune
        callbacks=[grad_tracker],
        verbose=1,
    )

    # Save gradient history locally for inspection
    with open("keras_gradients.json", "w") as f:
        json.dump(grad_tracker.history, f, indent=2)
    print("Saved gradient stats to keras_gradients.json")

    # Step 4: Evaluate Keras on validation set
    y_val_pred = keras_model.predict(X_val_np).ravel()
    keras_auc = roc_auc_score(y_val.values, y_val_pred)
    keras_acc = accuracy_score(y_val.values, (y_val_pred >= 0.5).astype(int))

    # Example: simple gradient quality score (for analysis)
    last_grad = grad_tracker.history[-1]
    grad_quality = {
        "last_epoch_grad_abs_mean": last_grad["grad_abs_mean"],
        "last_epoch_grad_abs_max": last_grad["grad_abs_max"],
        "last_epoch_grad_std": last_grad["grad_std"],
    }

    print("\n=== MODEL SUMMARY (local) ===")
    print(f"Best sklearn: {best_sklearn_name} AUC={best_sklearn_auc:.4f}")
    print(f"Keras model : AUC={keras_auc:.4f} ACC={keras_acc:.4f}")
    print(f"SGD (for potential Lambda): AUC={sgd_auc:.4f}")
    print(f"Gradient quality (keras): {grad_quality}")

    # picking keras because it comes very close to gradient boosting, but can obtain more metrics easily
    final_model_name = "keras_model"
    final_auc = keras_auc

    print(f"\nFINAL CHOICE (for your report): {final_model_name} AUC={final_auc:.4f}")

    # Step 6: Build leaderboard (for analysis/report)
    model_leaderboard = []
    for name, model_obj, auc_val in sk_results:
        model_leaderboard.append(
            {
                "name": name,
                "type": "sklearn",
                "auc": float(auc_val),
            }
        )

    # Add Keras to leaderboard
    model_leaderboard.append(
        {
            "name": "keras_mlp",
            "type": "keras",
            "auc": float(keras_auc),
            "accuracy": float(keras_acc),
            "grad_abs_mean": float(grad_tracker.history[-1]["grad_abs_mean"]),
            "grad_abs_max": float(grad_tracker.history[-1]["grad_abs_max"]),
            "grad_std": float(grad_tracker.history[-1]["grad_std"]),
        }
    )

    # At this point you can:
    #   - Save model_leaderboard to disk as JSON or CSV for inspection.
    #   - Create plots (e.g., bar charts of AUC/accuracy) in a separate script/notebook.
    with open("model_leaderboard_telco.json", "w") as f:
        json.dump(model_leaderboard, f, indent=2)
    print("Saved model_leaderboard_telco.json")

    # plot gradient performance for the keras model
    # obtain metrics by epoch
    grad_df = pd.DataFrame({
        "Epoch": [g["epoch"] + 1 for g in grad_tracker.history],
        "Mean |Grad|": [g["grad_abs_mean"] for g in grad_tracker.history],
        "Max |Grad|": [g["grad_abs_max"] for g in grad_tracker.history],
        "Std |Grad|": [g["grad_std"] for g in grad_tracker.history],
    })

    grad_long = grad_df.melt(id_vars="Epoch", var_name="Metric", value_name="Value")

    fig, ax = plt.subplots(figsize=(8, 5))
    sns.lineplot(data=grad_long, x="Epoch", y="Value", hue="Metric", ax=ax,
                 palette={"Mean |Grad|": "seagreen", "Max |Grad|": "tomato", "Std |Grad|": "steelblue"},
                 marker="o", markersize=4)
    ax.set_title("Gradient Magnitudes Over Epochs")
    ax.set_xlabel("Epoch")
    ax.set_ylabel("Gradient Value")

    plt.tight_layout()
    plt.savefig("gradient_magnitudes.png", dpi=150, bbox_inches="tight")
    plt.close(fig)
    print("Saved gradient_magnitudes.png")

if __name__ == "__main__":
    main()
